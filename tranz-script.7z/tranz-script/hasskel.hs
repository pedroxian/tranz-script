--ghc 8.6.3

main = putStrLn "sinclair"

xorg.data string.java /escalibrator

mime:alt range.2 raw.memorie

call cod-warzone.dat data
rem script.plus /minus.alva

rat.poison/humanity .rad
e3.rad -studio

rad.5 ,-eclect polarity.rad6