--ghc 8.6.3

main = putStrLn "Hello, Dcoder!"
 /assign prometheus.create{products}made.japan
 syth.energy.capsule use.yumi(6.9)
 
 trash.2=prometheus.act2 use.code{preferences}
 
 prometheus{activate.calculator.dx5}made.new
 use.preferences=dr.202